import discord
from discord.ext import commands, tasks
import time

intents = discord.Intents.default()
intents.members = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'Middleman Bot logged in as {bot.user.name}')
    update_member_count.start()

@tasks.loop(seconds=10)  # Update member count every 10 seconds (adjust as needed)
async def update_member_count():
    server = bot.get_guild(YOURSERVERID) # the server id of the server you want the members counted from
    if server:
        member_count = len(server.members)
        with open("member_count.txt", "w") as file:
            file.write(str(member_count))

bot.run('YOURBOTTOKEN') # your bots token so it can run

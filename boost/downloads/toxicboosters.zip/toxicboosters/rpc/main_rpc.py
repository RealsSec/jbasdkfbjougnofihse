import discord
from pypresence import Presence
import time

# Put in your client id
RPC = Presence(client_id='YOUCLIENTID')
RPC.connect()
# Put in your client id

# Change the buttons
buttons = [
    {
        "label": "Website",
        "url": "https://realtoxic.org/ugc" 
    },
    {
        "label": "Discord Server",
        "url": "https://discord.gg/ugFRUmQCeZ"
    }
]
# Change the buttons


def update_rpc_presence(member_count):
    rpc_data = {
        "state": f"Members: {member_count}",
        "large_image": "https://64.media.tumblr.com/12692e2eaa44dc692396c5a2989e0483/e17be95a6f7a0ff3-39/s500x750/d22baaa6defabba51dd8d2b42dfd066a42ad45f1.gif", # the image
        "large_text": "realtoxic.org", # the text of the image
        "buttons": buttons,  
        "start": int(time.time())  
    }

    RPC.update(**rpc_data)


# DONT TOUCH BELOW HERE UNLESS YK WTF YOUR DOING
if __name__ == '__main__':
    while True:
        try:
            with open("member_count.txt", "r") as file:
                member_count = int(file.read())
                update_rpc_presence(member_count)
        except FileNotFoundError:
            print("Member count file not found.")
            
        except ValueError:
            print("Invalid member count data in the file.")
            
        time.sleep(60)  # Update the rpc every minute (adjust as needed dont put to low or you will get flagged for spamming!) 
